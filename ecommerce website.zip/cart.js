// Selecting elements
const listcarthtml = document.querySelector('.cart-items-container');
const iconcartspan = document.querySelector('.quantity');
let listproducts = [];
let carts = [];

// Function to toggle cart dialog
function toggleCartDialog() {
    listcarthtml.classList.toggle('show');
}

// Function to add event listener to "Add to Cart" buttons
document.querySelectorAll('.btn').forEach(button => {
    button.addEventListener('click', addToCart);
});

// Function to handle adding items to the cart
function addToCart(event) {
    event.preventDefault();
    const product = {
        id: event.target.dataset.id,
        name: event.target.dataset.name,
        price: parseFloat(event.target.dataset.price),
        image: event.target.dataset.image,
        quantity: 1
    };

    const existingItemIndex = carts.findIndex(item => item.id === product.id);
    if (existingItemIndex !== -1) {
        carts[existingItemIndex].quantity++;
    } else {
        carts.push(product);
    }

    updateCart();
}

// Function to update cart HTML
function updateCart() {
    listcarthtml.innerHTML = '';
    let totalquantity = 0;

    if (carts.length > 0) {
        carts.forEach(cart => {
            totalquantity += cart.quantity * cart.price;
            const newcart = document.createElement('div');
            newcart.classList.add('item');
            newcart.dataset.id = cart.id;
            newcart.innerHTML = `
                <div class="image">
                    <img src="${cart.image}" alt="">
                </div>
                <div class="name">${cart.name}</div>
                <div class="totalprice">
                    <span>&#8377;</span>${cart.price * cart.quantity }
                </div>
                <div class="quantity">
                    <span class="minus">-</span>
                    <span>${cart.quantity}</span>
                    <span class="plus">+</span>
                </div>
            `;
            listcarthtml.appendChild(newcart);
        });
    }

    iconcartspan.innerText = totalquantity.toFixed(2);
    document.getElementById('subtotal').innerHTML = `
        SUBTOTAL :<span>&#8377;</span>${totalquantity.toFixed(2)}
    `;
}

// Event listener for clicks within the cart items container
listcarthtml.addEventListener('click', (event) => {
    const positionclick = event.target;
    if (positionclick.classList.contains('minus') || positionclick.classList.contains('plus')) {
        const product_id = positionclick.parentElement.parentElement.dataset.id;
        const type = positionclick.classList.contains('plus') ? 'plus' : 'minus';
        changeQuantity(product_id, type);
    }
});

// Function to change quantity of items in the cart
function changeQuantity(product_id, type) {
    const positionItemInCart = carts.findIndex(item => item.id === product_id);
    if (positionItemInCart !== -1) {
        if (type === 'plus') {
            carts[positionItemInCart].quantity++;
        } else {
            if (carts[positionItemInCart].quantity > 1) {
                carts[positionItemInCart].quantity--;
            } else {
                carts.splice(positionItemInCart, 1);
            }
        }
    }

    updateCart();
    addCartToMemory();
}

// Function to initialize the app
const initApp = () => {
    fetch('products.json')
        .then(response => response.json())
        .then(data => {
            listproducts = data;
            if (localStorage.getItem('cart')) {
                carts = JSON.parse(localStorage.getItem('cart'));
            }
            updateCart();
        });
};

initApp();

// Event listener for cancel button to clear the cart
document.getElementById("cancelButton").addEventListener("click", clearCart);

// Function to clear the cart
function clearCart() {
    carts = [];
    updateCart();
    addCartToMemory();
}

// Function to save the cart to localStorage
const addCartToMemory = () => {
    localStorage.setItem('cart', JSON.stringify(carts));
};

// Function to find the user's location
const findMyState = () => {
    const location = document.querySelector('.location');
    const success = (position) => {
        const latitude = position.coords.latitude;
        const longitude = position.coords.longitude;
        const geoApiUrl = `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`;
        fetch(geoApiUrl)
            .then(res => res.json())
            .then(data => {
                location.textContent = data.city + ', ' + data.principalSubdivision;
            });
    };
    const error = () => {
        location.textContent = 'Location';
    };
    navigator.geolocation.getCurrentPosition(success, error);
};

findMyState();
