window.onload = () => {
    const boxes = document.querySelectorAll(".box");
    boxes.forEach((box, index) => {
        setTimeout(() => {
            box.style.top = "0";
        }, index * 300);
    });
};
document.body.addEventListener("click",()=>{
    window.location.href="sign.html";

});