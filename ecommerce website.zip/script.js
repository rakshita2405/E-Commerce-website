let navbar = document.querySelector('.navbar');
let searchForm = document.querySelector('.search-form');
let cartItem = document.querySelector('.cart-items-container');

document.querySelector('#menu-btn').onclick = () => {
    navbar.classList.toggle('active');
    searchForm.classList.remove('active');
    cartItem.classList.remove('active');
};

document.querySelector('#search-btn').onclick = () => {
    searchForm.classList.toggle('active');
    navbar.classList.remove('active');
    cartItem.classList.remove('active');
};

// document.querySelector('#cart-btn').onclick = () => {
//     cartItem.classList.toggle('active');
//     navbar.classList.remove('active');
//     searchForm.classList.remove('active');
// };

window.onscroll = () => {
    navbar.classList.remove('active');
    searchForm.classList.remove('active');
    cartItem.classList.remove('active');
};

const soundIcon = document.getElementById('volume');
const audio = document.getElementById('audio');

soundIcon.addEventListener('click', () => {
    const icon = soundIcon.querySelector('i');
    if (audio.paused) {
        audio.play();
        icon.classList.remove("fa-volume-off");
        icon.classList.add("fa-volume-high");
    } else {
        audio.pause();
        audio.currentTime = 0;
        icon.classList.remove("fa-volume-high");
        icon.classList.add("fa-volume-off");
    }
});

const modeT = document.getElementById('mode');
const modeIcon = document.getElementById('mode-icon');
const body = document.body;

modeT.addEventListener('click', () => {
    body.classList.toggle('dark-mode');
    body.classList.toggle('light-mode');
    modeIcon.classList.toggle('fa-sun');
    modeIcon.classList.toggle('fa-moon');
});

document.addEventListener("DOMContentLoaded", function() {
    const heartIcons = document.querySelectorAll(".heart-icon");

    heartIcons.forEach(function(heartIcon) {
        heartIcon.addEventListener("click", function(event) {
            event.preventDefault(); // Prevent the default anchor behavior
            if (this.style.color === 'red') {
                this.style.color = 'white';
            } else {
                this.style.color = 'red';
            }
        });
    });

    const eyeIcons = document.querySelectorAll('.fa-eye');
    const modal = document.getElementById('imageModal');
    const modalImg = document.getElementById('zoomedImage');
    const closeBtn = document.querySelector('.close');

    eyeIcons.forEach(eyeIcon => {
        eyeIcon.addEventListener('click', function(event) {
            event.preventDefault(); // Prevent default anchor behavior
            const productBox = eyeIcon.closest('.box');
            const productImage = productBox.querySelector('.image img').src;

            modal.style.display = "block";
            modalImg.src = productImage;
        });
    });

    closeBtn.addEventListener('click', function() {
        modal.style.display = "none";
    });

    modal.addEventListener('click', function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    });
});
document.addEventListener('DOMContentLoaded', () => {
    const currentUserName = document.getElementById('currentUserName');
    const logoutLink = document.getElementById('logoutLink');
    const storedUser = JSON.parse(localStorage.getItem('user'));
  
    if (storedUser) {
      currentUserName.textContent = `Welcome, ${storedUser.name}`;
      logoutLink.style.display = 'block';
    } else {
      logoutLink.style.display = 'none';
    }
  
    logoutLink.addEventListener('click', (e) => {
      e.preventDefault();
      localStorage.removeItem('user');
      window.location.href = 'sign.html';
    });
  });
  
  

// Function to disable icon functionalities if user is not logged in
const logoutLink = document.querySelector('#logoutLink');

// Check if the user is logged in
function isLoggedIn() {
    return localStorage.getItem('isLoggedIn') === 'true';
}

// Event listener for logout link
// logoutLink.addEventListener('click', (e) => {
//     e.preventDefault(); // Prevent the default behavior of the link

//     // Remove user data from local storage
//     localStorage.removeItem('user');
//     localStorage.setItem('isLoggedIn', 'false'); // Update login status

//     // Display alert indicating user logout
//     alert('You have been logged out.');
// });

// Check if the user is not logged in and disable icon functionalities
console.log('Is user logged in?', isLoggedIn());

document.addEventListener("DOMContentLoaded", function() {
    const addToCartButtons = document.querySelectorAll('.btn');
    const cartQuantity = document.querySelector('.quantity');
    let cartCount = 0;
    let addedItems = [];

    addToCartButtons.forEach(button => {
        if (button.textContent.toLowerCase() === "add to cart") {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                cartCount++;
                cartQuantity.textContent = cartCount;
                const itemName = button.closest('.box').querySelector('h3').textContent;
                addedItems.push(itemName);
                showCartDialog(addedItems);
            });
        }
    });

    const cartIcon = document.getElementById('cart-btn');
    cartIcon.addEventListener('click', () => {
        showCartDialog(addedItems);
    });

    function showCartDialog(addedItems) {
        let dialogContent;
        if (addedItems.length > 0) {
            dialogContent = 'Items added to cart:\n';
            addedItems.forEach(item => {
                dialogContent += '- ' + item + '\n';
            });
            dialogContent += 'Do you want to place an order?';
        } else {
            dialogContent = 'No items added to cart yet.';
        }

        const confirmed = confirm(dialogContent);
        if (confirmed) {
            alert('Your order has been placed!');
            // Here you can add further logic for order placement
            // For example, send the order to the server, reset the cart, etc.
        }
    }
});



