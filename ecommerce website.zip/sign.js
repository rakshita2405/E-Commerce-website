const container = document.getElementById('container');
const registerToggleBtn = document.getElementById('registerToggleBtn');
const loginToggleBtn = document.getElementById('loginToggleBtn');
const signUpForm = document.getElementById('signUpForm');
const loginForm = document.getElementById('loginForm');

// Toggle between signup and login forms
registerToggleBtn.addEventListener('click', () => {
  container.classList.add('active');
});

loginToggleBtn.addEventListener('click', () => {
  container.classList.remove('active');
});

// Handle signup
signUpForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const name = signUpForm.querySelector('input[placeholder="Name"]').value;
  const email = signUpForm.querySelector('input[placeholder="Email"]').value;
  const password = signUpForm.querySelector('input[placeholder="Password"]').value;

  if (name && email && password) {
    // Store user data in local storage
    const user = { name, email, password };
    localStorage.setItem('user', JSON.stringify(user));
    alert('Account created successfully!');
    container.classList.remove('active'); // Switch to login form
  } else {
    alert('Please fill out all fields.');
  }
});

// Handle login
loginForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const email = loginForm.querySelector('input[placeholder="Email"]').value;
  const password = loginForm.querySelector('input[placeholder="Password"]').value;

  const storedUser = JSON.parse(localStorage.getItem('user'));

  if (storedUser && storedUser.email === email && storedUser.password === password) {
    alert(`Welcome back, ${storedUser.name}!`);
    // Redirect to main page
    window.location.href = 'index.html';
  } else {
    alert('Invalid email or password.');
  }
});
